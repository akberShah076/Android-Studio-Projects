package com.example.notificationsender;
public class EventData {
    private String eventName;
    private long eventDateTimestamp;

    public EventData(String eventName, long eventDateTimestamp) {
        this.eventName = eventName;
        this.eventDateTimestamp = eventDateTimestamp;
    }

    public String getEventName() {
        return eventName;
    }

    public long getEventDateTimestamp() {
        return eventDateTimestamp;
    }
}
