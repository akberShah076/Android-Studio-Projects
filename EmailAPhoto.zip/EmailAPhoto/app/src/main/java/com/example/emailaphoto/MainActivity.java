package com.example.emailaphoto;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private static final int PICK_PHOTO_REQUEST = 1;
    private static final int PICK_CONTACT_REQUEST = 2;
    private static final int PERMISSIONS_REQUEST_READ_CONTACTS = 100;

    private Uri selectedPhotoUri;
    private String selectedEmailAddress;
    private TextView selectedContactTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Remove setContentView(R.layout.activity_main);

        // No need for buttons and listeners
        selectedContactTextView = new TextView(this);

        // Start the process
        selectPhoto();
    }

    private void selectPhoto() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_PHOTO_REQUEST);
    }

    private void selectContact() {
        Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
        startActivityForResult(intent, PICK_CONTACT_REQUEST);
    }

    private void sendEmail() {
        if (selectedPhotoUri != null && selectedEmailAddress != null) {
            Intent emailIntent = new Intent(Intent.ACTION_SEND);
            emailIntent.setType("vnd.android.cursor.dir/email");
            emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{selectedEmailAddress});
            emailIntent.putExtra(Intent.EXTRA_STREAM, selectedPhotoUri);
            //emailIntent.putExtra(Intent.EXTRA_STREAM, selectedPhotoUri); //extra subject
            //emailIntent.putExtra(Intent.EXTRA_STREAM, selectedPhotoUri); //Extra text
            emailIntent.setType("image/jpeg");
            startActivity(Intent.createChooser(emailIntent, "Send email..."));
        } else {
            Toast.makeText(this, "Select both a photo and a contact first", Toast.LENGTH_SHORT).show();
        }
    }

    private void requestContactPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            // Explanation for the need for contact permission
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_CONTACTS)) {
                Toast.makeText(this, "Contacts permission is needed to select a contact.", Toast.LENGTH_LONG).show();
            }
            // Request the permission
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_CONTACTS}, PERMISSIONS_REQUEST_READ_CONTACTS);
        } else {
            // Permission has already been granted
            selectContact();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSIONS_REQUEST_READ_CONTACTS) {
            // If request is cancelled, the result arrays are empty.
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission was granted
                selectContact();
            } else {
                // Permission denied
                Toast.makeText(this, "Permission denied to read contacts", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_PHOTO_REQUEST && resultCode == RESULT_OK && data != null) {
            selectedPhotoUri = data.getData();
            // Continue the process
            selectContact();
        } else if (requestCode == PICK_CONTACT_REQUEST && resultCode == RESULT_OK && data != null) {
            Uri contactUri = data.getData();
            retrieveContactEmail(contactUri);
            // Continue the process
            sendEmail();
        }
    }

    private void retrieveContactEmail(Uri contactUri) {
        String[] projection = new String[]{
                ContactsContract.Contacts.DISPLAY_NAME,
                ContactsContract.Contacts._ID
        };

        try (Cursor cursor = getContentResolver().query(contactUri, projection, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int nameIndex = cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME);
                int idIndex = cursor.getColumnIndex(ContactsContract.Contacts._ID);

                if (nameIndex != -1 && idIndex != -1) {
                    String name = cursor.getString(nameIndex);
                    String contactId = cursor.getString(idIndex);
                    // Display the selected contact (optional)
                    selectedContactTextView.setText("Selected Contact: " + name);
                    findEmail(contactId);
                } else {
                    Toast.makeText(this, "Required column not found", Toast.LENGTH_SHORT).show();
                }
            }
        } catch (Exception e) {
            Toast.makeText(this, "Failed to retrieve contact", Toast.LENGTH_SHORT).show();
        }
    }

    private void findEmail(String contactId) {
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(
                    ContactsContract.CommonDataKinds.Email.CONTENT_URI,
                    null,
                    ContactsContract.CommonDataKinds.Email.CONTACT_ID + " = ?",
                    new String[]{contactId},
                    null);

            int emailIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.DATA);

            // Check if the email column index is valid and cursor is not empty
            if (emailIndex != -1 && cursor.moveToFirst()) {
                selectedEmailAddress = cursor.getString(emailIndex);
            } else {
                Toast.makeText(this, "Email not found for contact", Toast.LENGTH_SHORT).show();
                selectedEmailAddress = null; // Reset email address as it's not found
            }
        } catch (Exception e) {
            Toast.makeText(this, "Failed to retrieve contact's email", Toast.LENGTH_SHORT).show();
            selectedEmailAddress = null; // Reset email address on error
        } finally {
            if (cursor != null) {
                cursor.close(); // Ensure cursor is closed after operation
            }
        }
    }
}
